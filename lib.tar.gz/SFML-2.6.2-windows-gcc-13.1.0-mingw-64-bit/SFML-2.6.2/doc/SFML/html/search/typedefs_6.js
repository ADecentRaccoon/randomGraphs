var searchData=
[
  ['scancode_0',['Scancode',['../classsf_1_1Keyboard.html#a333a0916fe00761c8ebe8056c64ba470',1,'sf::Keyboard']]],
  ['sockethandle_1',['SocketHandle',['../namespacesf.html#aefabb521d8f5eec9e6a9b521271d20d1',1,'sf']]]
];
